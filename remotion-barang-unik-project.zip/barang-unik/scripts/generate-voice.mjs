// Membuat voice over Bahasa Indonesia untuk tiap adegan.
// Memakai edge-tts (suara natural, gratis). Jika gagal, otomatis fallback ke gTTS.
//
// Pengaturan opsional (environment variable):
//   VOICE=id-ID-ArdiNeural    (pria)  |  id-ID-GadisNeural (wanita)
//   RATE=+0%                  (contoh: -10% lebih lambat, +10% lebih cepat)
//   FORCE=1                   (buat ulang walau file sudah ada)
import fs from "node:fs";
import {execFileSync} from "node:child_process";

const content = JSON.parse(fs.readFileSync("src/content.json", "utf8"));
const VOICE = process.env.VOICE || "id-ID-ArdiNeural";
const RATE = process.env.RATE || "+0%";
const FORCE = process.env.FORCE === "1";
const OUT = "public/voice";
fs.mkdirSync(OUT, {recursive: true});

const scenes = [
  {id: "intro", text: content.intro.narration},
  ...content.items.map((i) => ({id: i.id, text: i.narration})),
  {id: "outro", text: content.outro.narration},
];

function tryRun(cmd, args) {
  execFileSync(cmd, args, {stdio: "pipe"});
}

function edge(text, file) {
  const args = ["--voice", VOICE, `--rate=${RATE}`, "--text", text, "--write-media", file];
  try { tryRun("edge-tts", args); }
  catch { tryRun("python3", ["-m", "edge_tts", ...args]); }
}

function gtts(text, file) {
  try { tryRun("gtts-cli", [text, "-l", "id", "-o", file]); }
  catch { tryRun("python3", ["-m", "gtts.cli", text, "-l", "id", "-o", file]); }
}

let failed = 0;
for (const s of scenes) {
  const file = `${OUT}/${s.id}.mp3`;
  if (fs.existsSync(file) && !FORCE) { console.log("lewati (sudah ada):", file); continue; }
  try {
    edge(s.text, file);
    console.log("voice (edge-tts):", file);
  } catch (e1) {
    console.warn(`edge-tts gagal untuk ${s.id}, mencoba gTTS...`);
    try {
      gtts(s.text, file);
      console.log("voice (gTTS):", file);
    } catch (e2) {
      failed++;
      console.error(`GAGAL membuat suara untuk ${s.id}. Pastikan: pip install edge-tts gTTS`);
    }
  }
}
if (failed) {
  console.error(`\n${failed} voice over gagal dibuat. Video tetap bisa dirender, tetapi tanpa suara pada adegan tersebut.`);
}
