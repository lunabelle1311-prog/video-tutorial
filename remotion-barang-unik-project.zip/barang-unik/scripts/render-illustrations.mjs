// Render ilustrasi 3D tiap barang menjadi PNG transparan (bisa dipakai ulang di editor video/thumbnail).
import fs from "node:fs";
import {execFileSync} from "node:child_process";

const content = JSON.parse(fs.readFileSync("src/content.json", "utf8"));
fs.mkdirSync("out/ilustrasi", {recursive: true});

for (const item of content.items) {
  const slug = item.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const file = `out/ilustrasi/${String(item.number).padStart(2, "0")}-${slug}.png`;
  const props = JSON.stringify({type: item.model});
  console.log("ilustrasi 3D:", file);
  execFileSync(
    "npx",
    ["remotion", "still", "src/index.ts", "Ilustrasi3D", file, `--props=${props}`, "--frame=60", "--gl=angle", "--image-format=png"],
    {stdio: "inherit"}
  );
}
