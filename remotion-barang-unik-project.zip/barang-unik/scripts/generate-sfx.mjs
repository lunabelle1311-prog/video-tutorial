// Membuat sound effect + musik latar secara prosedural (tanpa unduhan, tanpa hak cipta).
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = "public/sfx";
fs.mkdirSync(OUT, {recursive: true});

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const midi = (m) => 440 * Math.pow(2, (m - 69) / 12);

function normalize(s, peak = 0.85) {
  let max = 0;
  for (const v of s) max = Math.max(max, Math.abs(v));
  if (max > 0) for (let i = 0; i < s.length; i++) s[i] = (s[i] / max) * peak;
  return s;
}

function writeWav(name, samples) {
  const n = samples.length;
  const b = Buffer.alloc(44 + n * 2);
  b.write("RIFF", 0); b.writeUInt32LE(36 + n * 2, 4); b.write("WAVE", 8);
  b.write("fmt ", 12); b.writeUInt32LE(16, 16); b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22); b.writeUInt32LE(SR, 24); b.writeUInt32LE(SR * 2, 28);
  b.writeUInt16LE(2, 32); b.writeUInt16LE(16, 34);
  b.write("data", 36); b.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i]));
    b.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  fs.writeFileSync(path.join(OUT, name), b);
  console.log("sfx:", name, (b.length / 1024).toFixed(0) + " KB");
}

// Whoosh: noise + low-pass yang naik lalu turun
function whoosh() {
  const dur = 0.9, s = buf(dur), r = rng(7);
  let lp = 0;
  for (let i = 0; i < s.length; i++) {
    const t = i / SR, u = t / dur;
    const env = Math.pow(Math.sin(Math.PI * u), 2);
    const cutoff = 0.02 + 0.3 * Math.sin(Math.PI * u);
    lp += cutoff * ((r() * 2 - 1) - lp);
    s[i] = Math.tanh(lp * 6 * env) * 0.7;
  }
  return normalize(s, 0.8);
}

// Pop: sapuan nada turun cepat
function pop() {
  const s = buf(0.25); let ph = 0;
  for (let i = 0; i < s.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (180 + 700 * Math.exp(-t * 20))) / SR;
    s[i] = Math.sin(ph) * Math.exp(-t * 26);
  }
  return normalize(s, 0.8);
}

// Tick halus
function tick() {
  const s = buf(0.1);
  for (let i = 0; i < s.length; i++) {
    const t = i / SR;
    s[i] = Math.sin(2 * Math.PI * 1800 * t) * Math.exp(-t * 55);
  }
  return normalize(s, 0.6);
}

// Ding / lonceng
function bell(freq, len = 1.6, decay = 3.2) {
  const s = buf(len);
  const parts = [[1, 1], [2.01, 0.4], [3.02, 0.18], [4.2, 0.08]];
  for (let i = 0; i < s.length; i++) {
    const t = i / SR; let v = 0;
    for (const [m, a] of parts) v += a * Math.sin(2 * Math.PI * freq * m * t) * Math.exp(-t * decay * m * 0.6);
    s[i] = v * Math.min(1, t / 0.003);
  }
  return s;
}
function ding() { return normalize(bell(880), 0.7); }

// Impact: dentuman rendah saat nomor muncul
function impact() {
  const s = buf(0.7), r = rng(3); let ph = 0;
  for (let i = 0; i < s.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (45 + 90 * Math.exp(-t * 12))) / SR;
    s[i] = Math.sin(ph) * Math.exp(-t * 6) + (r() * 2 - 1) * 0.25 * Math.exp(-t * 45);
  }
  return normalize(s, 0.9);
}

// Success: arpeggio naik
function success() {
  const s = buf(2.0);
  [72, 76, 79, 84].forEach((m, k) => {
    const b = bell(midi(m), 1.6, 2.6), off = Math.floor(k * 0.13 * SR);
    for (let i = 0; i < b.length && i + off < s.length; i++) s[i + off] += b[i] * 0.6;
  });
  return normalize(s, 0.7);
}

// Musik latar: progresi Am - F - C - G, lembut, loop ~21 detik
function music() {
  const bpm = 92, beat = 60 / bpm, bars = 8, total = bars * 4 * beat;
  const s = buf(total), r = rng(11);
  const chords = [[57, 60, 64], [53, 57, 60], [60, 64, 67], [55, 59, 62]];
  const chordLen = 8 * beat; // 2 bar per chord
  const add = (i, v) => { if (i >= 0 && i < s.length) s[i] += v; };
  chords.forEach((ch, ci) => {
    const t0 = ci * chordLen;
    // Pad
    for (let i = 0; i < chordLen * SR; i++) {
      const t = i / SR;
      const env = Math.min(1, t / 0.6, (chordLen - t) / 0.6);
      let v = 0;
      for (const m of ch) v += Math.sin(2 * Math.PI * midi(m) * t) + 0.3 * Math.sin(2 * Math.PI * midi(m) * 2 * t);
      add(Math.floor(t0 * SR) + i, v * 0.05 * Math.max(0, env));
    }
    // Bass tiap ketukan 1 & 3
    for (let b = 0; b < 8; b += 2) {
      const bt = t0 + b * beat, f = midi(ch[0] - 24);
      for (let i = 0; i < beat * 1.6 * SR; i++) {
        const t = i / SR;
        add(Math.floor(bt * SR) + i, Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 3) * 0.22);
      }
    }
    // Pluck arpeggio per 1/8
    const pat = [0, 1, 2, 1, 2, 1, 0, 1];
    for (let e = 0; e < 16; e++) {
      const bt = t0 + e * (beat / 2), f = midi(ch[pat[e % 8]] + 12);
      for (let i = 0; i < 0.5 * SR; i++) {
        const t = i / SR;
        const v = Math.sin(2 * Math.PI * f * t) + 0.4 * Math.sin(2 * Math.PI * f * 2 * t);
        add(Math.floor(bt * SR) + i, v * Math.exp(-t * 9) * 0.09);
      }
    }
    // Hi-hat tipis di off-beat
    for (let e = 1; e < 16; e += 2) {
      const bt = t0 + e * (beat / 2);
      for (let i = 0; i < 0.05 * SR; i++) {
        add(Math.floor(bt * SR) + i, (r() * 2 - 1) * Math.exp(-(i / SR) * 90) * 0.04);
      }
    }
  });
  // fade sangat singkat di ujung agar loop tidak "klik"
  const fade = Math.floor(0.05 * SR);
  for (let i = 0; i < fade; i++) { s[s.length - 1 - i] *= i / fade; s[i] *= i / fade; }
  return normalize(s, 0.8);
}

writeWav("whoosh.wav", whoosh());
writeWav("pop.wav", pop());
writeWav("tick.wav", tick());
writeWav("ding.wav", ding());
writeWav("impact.wav", impact());
writeWav("success.wav", success());
writeWav("music.wav", music());
