// Mengemas semua hasil ke dalam satu file ZIP.
import fs from "node:fs";
import path from "node:path";
import archiver from "archiver";

const content = JSON.parse(fs.readFileSync("src/content.json", "utf8"));
const ZIP = "out/barang-unik-youtube.zip";
fs.mkdirSync("out", {recursive: true});

const output = fs.createWriteStream(ZIP);
const archive = archiver("zip", {zlib: {level: 9}});
const done = new Promise((resolve, reject) => {
  output.on("close", resolve);
  archive.on("error", reject);
});
archive.pipe(output);

const addIfExists = (src, dest) => {
  if (fs.existsSync(src)) archive.file(src, {name: dest});
  else console.warn("dilewati (tidak ditemukan):", src);
};
const addDir = (dir, dest, ext) => {
  if (!fs.existsSync(dir)) return;
  for (const f of fs.readdirSync(dir)) if (f.endsWith(ext)) archive.file(path.join(dir, f), {name: `${dest}/${f}`});
};

addIfExists("out/video.mp4", "01-video/barang-unik.mp4");
addIfExists("out/thumbnail.png", "02-thumbnail/thumbnail.png");
addDir("out/ilustrasi", "03-ilustrasi-3d", ".png");
addDir("public/voice", "04-voice-over", ".mp3");
addDir("public/sfx", "05-sound-effect", ".wav");

const narasi = [
  "[INTRO]\n" + content.intro.narration,
  ...content.items.map((i) => `[NOMOR ${i.number} - ${i.title}]\n${i.narration}`),
  "[OUTRO]\n" + content.outro.narration,
].join("\n\n");
archive.append(narasi, {name: "06-naskah/naskah-voice-over.txt"});

const meta = [
  "JUDUL:", content.videoTitle, "",
  "DESKRIPSI:", content.videoDescription, "",
  "HASHTAG:", content.hashtags.join(" "), "",
].join("\n");
archive.append(meta, {name: "06-naskah/metadata-youtube.txt"});

await archive.finalize();
await done;
console.log(`\nSelesai: ${ZIP} (${(fs.statSync(ZIP).size / 1048576).toFixed(1)} MB)`);
