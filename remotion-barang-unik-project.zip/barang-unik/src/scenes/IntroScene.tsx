import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {Background} from "../components/Background";
import {ModelRow} from "../components/Models3D";
import {Subtitle} from "../components/Subtitle";
import {Sfx} from "../components/Sfx";
import {intro, channel, scenes} from "../data";
import {FONT, INK, LEAD_SECONDS, MUTED} from "../theme";

const Word: React.FC<{text: string; delay: number; size: number; color: string; weight?: number}> = ({
  text, delay, size, color, weight = 800,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: {damping: 11, stiffness: 110}});
  return (
    <span
      style={{
        display: "inline-block",
        marginRight: size * 0.28,
        fontSize: size,
        fontWeight: weight,
        color,
        opacity: Math.min(1, p),
        transform: `translateY(${(1 - p) * 70}px) scale(${0.85 + 0.15 * p})`,
        letterSpacing: -1,
      }}
    >
      {text}
    </span>
  );
};

export const IntroScene: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lead = Math.round(LEAD_SECONDS * fps);
  const tag = spring({frame: frame - 55, fps, config: {damping: 14}});
  const color = "#6C7CFF";
  const w1 = intro.title1.split(" ");
  const w2 = intro.title2.split(" ");
  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      <Background color={color} />
      <Sfx src="whoosh" at={0} volume={0.6} />
      <Sfx src="impact" at={10} volume={0.7} />
      <Sfx src="pop" at={30} volume={0.4} />
      <Sfx src="pop" at={38} volume={0.4} />
      <Sfx src="pop" at={46} volume={0.4} />
      <Sfx src="pop" at={54} volume={0.4} />
      <Sfx src="pop" at={62} volume={0.4} />

      <div style={{position: "absolute", left: 110, top: 60, width: 1700}}>
        <div style={{display: "flex", alignItems: "center", gap: 14, marginBottom: 6, color: MUTED, fontSize: 30, fontWeight: 600}}>
          <div style={{width: 14, height: 14, borderRadius: 7, background: "#FFD60A"}} />
          {channel}
        </div>
        <div style={{lineHeight: 1.02}}>
          {w1.map((w, i) => (
            <Word key={i} text={w} delay={6 + i * 6} size={150} color="#FFD60A" />
          ))}
        </div>
        <div style={{lineHeight: 1.2, marginTop: 4}}>
          {w2.map((w, i) => (
            <Word key={i} text={w} delay={20 + i * 5} size={66} color={INK} weight={700} />
          ))}
        </div>
        <div
          style={{
            marginTop: 14,
            fontSize: 32,
            fontWeight: 500,
            color: MUTED,
            opacity: tag,
            transform: `translateY(${(1 - tag) * 20}px)`,
          }}
        >
          {intro.tagline}
        </div>
      </div>

      <div style={{position: "absolute", left: 0, top: 430, width: 1920, height: 500}}>
        <ModelRow width={1920} height={500} />
      </div>

      <Subtitle text={scenes[0].narration} start={lead} end={duration - Math.round(0.6 * fps)} color={color} />
    </AbsoluteFill>
  );
};
