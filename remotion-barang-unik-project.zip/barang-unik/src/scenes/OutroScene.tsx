import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {Background} from "../components/Background";
import {Subtitle} from "../components/Subtitle";
import {Sfx} from "../components/Sfx";
import {items, outro, scenes} from "../data";
import {FONT, INK, LEAD_SECONDS, MUTED} from "../theme";

const Bell: React.FC<{size: number; swing: number}> = ({size, swing}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{transform: `rotate(${swing}deg)`, transformOrigin: "50% 10%"}}>
    <path
      fill="#fff"
      d="M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2zm6-6V11c0-3.07-1.63-5.64-4.5-6.32V4a1.5 1.5 0 0 0-3 0v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"
    />
  </svg>
);

export const OutroScene: React.FC<{duration: number}> = ({duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lead = Math.round(LEAD_SECONDS * fps);
  const color = "#FF4D6D";
  const head = spring({frame: frame - 6, fps, config: {damping: 14}});
  const btnAt = Math.round(fps * 9);
  const btn = spring({frame: frame - btnAt, fps, config: {damping: 8, stiffness: 120}});
  const pulse = 1 + (frame > btnAt ? Math.sin((frame - btnAt) / 6) * 0.03 : 0);
  const swing = frame > btnAt ? Math.sin((frame - btnAt) / 3) * 18 * Math.exp(-(frame - btnAt) / 45) : 0;

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      <Background color={color} />
      <Sfx src="whoosh" at={0} volume={0.55} />
      <Sfx src="ding" at={14} volume={0.35} />
      {items.map((_, i) => (
        <Sfx key={i} src="pop" at={30 + i * 10} volume={0.4} />
      ))}
      <Sfx src="success" at={btnAt} volume={0.5} />

      <div style={{position: "absolute", left: 100, top: 70, width: 1000}}>
        <div
          style={{
            fontSize: 74, fontWeight: 800, color: INK, lineHeight: 1.08, letterSpacing: -1.5,
            opacity: head, transform: `translateY(${(1 - head) * 40}px)`,
          }}
        >
          {outro.title}
        </div>
        <div style={{marginTop: 18, fontSize: 36, fontWeight: 600, color: MUTED, opacity: head}}>{outro.cta}</div>
      </div>

      {/* Tombol subscribe */}
      <div
        style={{
          position: "absolute", right: 110, top: 105, height: 124, padding: "0 44px", borderRadius: 62,
          background: "#FF0033", display: "flex", alignItems: "center", gap: 22, color: "#fff",
          fontSize: 48, fontWeight: 800, boxShadow: "0 18px 50px rgba(255,0,51,0.45)",
          transform: `scale(${Math.min(1.1, btn) * pulse})`, opacity: Math.min(1, btn), transformOrigin: "right center",
        }}
      >
        <Bell size={64} swing={swing} />
        Subscribe
      </div>

      {/* Rekap lima barang */}
      <div style={{position: "absolute", left: 95, top: 330, width: 1730, display: "flex", gap: 20}}>
        {items.map((it, i) => {
          const p = spring({frame: frame - (30 + i * 10), fps, config: {damping: 13}});
          return (
            <div
              key={it.id}
              style={{
                flex: 1, minHeight: 300, borderRadius: 30, padding: "26px 24px",
                background: "rgba(255,255,255,0.08)", borderTop: `10px solid ${it.color}`,
                opacity: Math.min(1, p), transform: `translateY(${(1 - p) * 60}px)`,
                display: "flex", flexDirection: "column", gap: 14,
              }}
            >
              <div
                style={{
                  width: 58, height: 58, borderRadius: 18, background: it.color, color: "#0B1020",
                  fontSize: 38, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center",
                }}
              >
                {it.number}
              </div>
              <div style={{fontSize: 33, fontWeight: 800, color: INK, lineHeight: 1.15}}>{it.title}</div>
              <div style={{fontSize: 25, fontWeight: 500, color: MUTED, lineHeight: 1.3}}>{it.tagline}</div>
            </div>
          );
        })}
      </div>

      <Subtitle text={scenes[scenes.length - 1].narration} start={lead} end={duration - Math.round(0.6 * fps)} color={color} />
    </AbsoluteFill>
  );
};
