import React from "react";
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {Background} from "../components/Background";
import {Stage3D} from "../components/Models3D";
import {Subtitle} from "../components/Subtitle";
import {Sfx} from "../components/Sfx";
import type {Item} from "../data";
import {FONT, INK, LEAD_SECONDS, MUTED} from "../theme";

export const ItemScene: React.FC<{item: Item; duration: number}> = ({item, duration}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lead = Math.round(LEAD_SECONDS * fps);

  const badge = spring({frame: frame - 6, fps, config: {damping: 9, stiffness: 120}});
  const titleIn = spring({frame: frame - 14, fps, config: {damping: 14}});
  const factIn = spring({frame: frame - 34, fps, config: {damping: 14}});
  const panelIn = spring({frame: frame - 4, fps, config: {damping: 16}});

  const stepsStart = Math.round(3.4 * fps);
  const stepsEnd = duration - Math.round(1.6 * fps);
  const gap = Math.max(fps, (stepsEnd - stepsStart) / item.steps.length);
  const stepAt = (i: number) => Math.round(stepsStart + i * gap);

  return (
    <AbsoluteFill style={{fontFamily: FONT}}>
      <Background color={item.color} />
      <Sfx src="whoosh" at={0} volume={0.55} />
      <Sfx src="impact" at={8} volume={0.65} />
      <Sfx src="ding" at={36} volume={0.3} />
      {item.steps.map((_, i) => (
        <Sfx key={i} src="pop" at={stepAt(i)} volume={0.45} />
      ))}

      {/* Kolom kiri */}
      <div
        style={{
          position: "absolute", left: 90, top: 56, width: 930, height: 780,
          display: "flex", flexDirection: "column", justifyContent: "center", gap: 22,
        }}
      >
        <div style={{display: "flex", alignItems: "center", gap: 24}}>
          <div
            style={{
              width: 116, height: 116, borderRadius: 34, background: item.color, color: "#0B1020",
              fontSize: 78, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center",
              transform: `scale(${badge}) rotate(${(1 - badge) * -25}deg)`,
              boxShadow: `0 14px 40px ${item.color}88`,
            }}
          >
            {item.number}
          </div>
          <div style={{fontSize: 34, fontWeight: 600, color: item.color, opacity: titleIn}}>{item.tagline}</div>
        </div>

        <div
          style={{
            fontSize: 84, fontWeight: 800, color: INK, lineHeight: 1.05, letterSpacing: -1.5,
            opacity: titleIn, transform: `translateX(${(1 - titleIn) * -80}px)`,
          }}
        >
          {item.title}
        </div>

        <div
          style={{
            fontSize: 31, fontWeight: 500, color: MUTED, lineHeight: 1.4, paddingLeft: 24,
            borderLeft: `7px solid ${item.color}`, opacity: factIn, transform: `translateY(${(1 - factIn) * 20}px)`,
          }}
        >
          {item.fact}
        </div>

        <div style={{display: "flex", flexDirection: "column", gap: 12, marginTop: 6}}>
          {item.steps.map((s, i) => {
            const p = spring({frame: frame - stepAt(i), fps, config: {damping: 13, stiffness: 120}});
            return (
              <div
                key={i}
                style={{
                  display: "flex", alignItems: "center", gap: 20, padding: "0 26px", height: 70, borderRadius: 22,
                  background: "rgba(255,255,255,0.08)", border: `2px solid ${item.color}66`,
                  opacity: Math.min(1, p), transform: `translateX(${(1 - p) * -70}px) scale(${0.96 + 0.04 * p})`,
                }}
              >
                <div
                  style={{
                    width: 42, height: 42, borderRadius: 21, background: item.color, color: "#0B1020",
                    fontWeight: 800, fontSize: 24, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
                  }}
                >
                  {i + 1}
                </div>
                <div style={{fontSize: 31, fontWeight: 600, color: INK}}>{s}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Panel 3D kanan */}
      <div
        style={{
          position: "absolute", left: 1070, top: 60, width: 760, height: 780, borderRadius: 48,
          background: `radial-gradient(circle at 50% 40%, ${item.color}40, rgba(255,255,255,0.04) 70%)`,
          border: `2px solid ${item.color}77`, boxShadow: `0 30px 90px ${item.color}33`,
          overflow: "hidden", opacity: panelIn, transform: `scale(${0.92 + 0.08 * panelIn})`,
        }}
      >
        <Stage3D type={item.model} width={760} height={780} />
      </div>

      <Subtitle text={item.narration} start={lead} end={duration - Math.round(0.6 * fps)} color={item.color} />
    </AbsoluteFill>
  );
};
