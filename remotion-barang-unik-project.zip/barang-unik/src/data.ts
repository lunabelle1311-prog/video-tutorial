import content from "./content.json";

export type ModelType = "clip" | "band" | "foil" | "pen" | "silica";

export type Item = {
  id: string;
  number: number;
  title: string;
  tagline: string;
  fact: string;
  color: string;
  model: ModelType;
  steps: string[];
  narration: string;
};

export const items = content.items as unknown as Item[];
export const intro = content.intro;
export const outro = content.outro;
export const channel = content.channel;

export type SceneDef = {
  id: string;
  kind: "intro" | "item" | "outro";
  narration: string;
  item?: Item;
};

export const scenes: SceneDef[] = [
  {id: "intro", kind: "intro", narration: intro.narration},
  ...items.map((item) => ({id: item.id, kind: "item" as const, narration: item.narration, item})),
  {id: "outro", kind: "outro", narration: outro.narration},
];
