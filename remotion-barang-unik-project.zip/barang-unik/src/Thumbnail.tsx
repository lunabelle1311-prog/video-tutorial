import React from "react";
import {AbsoluteFill} from "remotion";
import {ModelRow} from "./components/Models3D";
import {FONT} from "./theme";

export const Thumbnail: React.FC = () => (
  <AbsoluteFill
    style={{
      fontFamily: FONT,
      background:
        "radial-gradient(700px 500px at 80% 30%, #6C7CFF66, transparent 65%), radial-gradient(600px 400px at 10% 90%, #FF6B6B44, transparent 65%), linear-gradient(135deg, #0B1020, #1b2a5e)",
    }}
  >
    <div style={{position: "absolute", left: 60, top: 26, lineHeight: 0.98}}>
      <div style={{fontSize: 175, fontWeight: 800, color: "#FFD60A", textShadow: "0 8px 0 #b38f00, 0 18px 40px rgba(0,0,0,0.5)", letterSpacing: -3}}>
        5 BARANG
      </div>
      <div style={{fontSize: 92, fontWeight: 800, color: "#fff", textShadow: "0 6px 24px rgba(0,0,0,0.6)", marginTop: 4}}>
        manfaatnya jarang
      </div>
      <div style={{fontSize: 92, fontWeight: 800, color: "#FF6B6B", textShadow: "0 6px 24px rgba(0,0,0,0.6)"}}>
        diketahui orang!
      </div>
    </div>
    <div style={{position: "absolute", left: 0, top: 400, width: 1280, height: 320}}>
      <ModelRow width={1280} height={320} animated={false} spacing={5.6} scale={1.25} />
    </div>
  </AbsoluteFill>
);
