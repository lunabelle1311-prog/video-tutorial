import React from "react";
import {Composition, Still, staticFile} from "remotion";
import {getAudioDurationInSeconds} from "@remotion/media-utils";
import {MainVideo, type VideoProps} from "./MainVideo";
import {Thumbnail} from "./Thumbnail";
import {Illustration, type IllustrationProps} from "./Illustration";
import {scenes} from "./data";
import {FPS, HEIGHT, LEAD_SECONDS, TAIL_SECONDS, WIDTH} from "./theme";

// Perkiraan durasi bila file voice over belum ada (± 2.4 kata per detik)
const estimate = (text: string) =>
  Math.round((text.split(/\s+/).length / 2.4 + LEAD_SECONDS + TAIL_SECONDS) * FPS);

const defaults: VideoProps = {
  durations: scenes.map((s) => estimate(s.narration)),
  voiceOk: scenes.map(() => false),
};

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="BarangUnik"
      component={MainVideo}
      durationInFrames={defaults.durations.reduce((a, b) => a + b, 0)}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={defaults}
      calculateMetadata={async () => {
        const results = await Promise.all(
          scenes.map(async (s) => {
            try {
              const sec = await getAudioDurationInSeconds(staticFile(`voice/${s.id}.mp3`));
              const frames = Math.max(5 * FPS, Math.ceil((sec + LEAD_SECONDS + TAIL_SECONDS) * FPS));
              return {frames, ok: true};
            } catch {
              return {frames: estimate(s.narration), ok: false};
            }
          })
        );
        const durations = results.map((r) => r.frames);
        return {
          durationInFrames: durations.reduce((a, b) => a + b, 0),
          props: {durations, voiceOk: results.map((r) => r.ok)},
        };
      }}
    />
    <Still id="Thumbnail" component={Thumbnail} width={1280} height={720} />
    <Still<IllustrationProps>
      id="Ilustrasi3D"
      component={Illustration}
      width={1080}
      height={1080}
      defaultProps={{type: "clip"}}
    />
  </>
);
