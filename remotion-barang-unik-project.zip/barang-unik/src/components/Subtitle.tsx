import React, {useMemo} from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {FONT} from "../theme";

const chunk = (text: string): string[] => {
  const parts = text.split(/(?<=[,.!?])\s+/).filter(Boolean);
  const out: string[] = [];
  let buf = "";
  for (const p of parts) {
    buf = buf ? `${buf} ${p}` : p;
    if (buf.length >= 48) {
      out.push(buf);
      buf = "";
    }
  }
  if (buf) {
    if (out.length && buf.length < 20) out[out.length - 1] += ` ${buf}`;
    else out.push(buf);
  }
  return out;
};

/** Teks narasi ditampilkan per potongan kalimat, dibagi sesuai panjang & durasi suara. */
export const Subtitle: React.FC<{text: string; start: number; end: number; color: string}> = ({
  text, start, end, color,
}) => {
  const frame = useCurrentFrame();
  const chunks = useMemo(() => chunk(text), [text]);
  const total = chunks.reduce((a, c) => a + c.length, 0);
  const span = Math.max(1, end - start);

  let acc = start;
  let current = -1;
  let segStart = 0;
  for (let i = 0; i < chunks.length; i++) {
    const len = (span * chunks[i].length) / total;
    if (frame >= acc && frame < acc + len) {
      current = i;
      segStart = acc;
      break;
    }
    acc += len;
  }
  if (current < 0) return null;

  const opacity = interpolate(frame - segStart, [0, 5], [0, 1], {extrapolateRight: "clamp"});
  return (
    <div style={{position: "absolute", left: 0, right: 0, bottom: 46, display: "flex", justifyContent: "center", opacity}}>
      <div
        style={{
          maxWidth: 1560,
          padding: "16px 36px",
          borderRadius: 26,
          background: "rgba(8,12,28,0.82)",
          border: `2px solid ${color}99`,
          color: "#fff",
          fontFamily: FONT,
          fontSize: 38,
          fontWeight: 600,
          lineHeight: 1.35,
          textAlign: "center",
        }}
      >
        {chunks[current]}
      </div>
    </div>
  );
};
