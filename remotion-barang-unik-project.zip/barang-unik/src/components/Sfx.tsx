import React from "react";
import {Audio, Sequence, staticFile} from "remotion";

/** Memutar sound effect pada frame tertentu di dalam adegan. */
export const Sfx: React.FC<{src: string; at: number; volume?: number}> = ({src, at, volume = 0.5}) => (
  <Sequence from={Math.max(0, Math.round(at))} durationInFrames={120} layout="none">
    <Audio src={staticFile(`sfx/${src}.wav`)} volume={volume} />
  </Sequence>
);
