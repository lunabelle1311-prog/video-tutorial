import React, {useMemo} from "react";
import * as THREE from "three";
import {ThreeCanvas} from "@remotion/three";
import {spring, useCurrentFrame, useVideoConfig} from "remotion";
import type {ModelType} from "../data";

type MP = {frame: number};

const Metal: React.FC<{color?: string; rough?: number}> = ({color = "#d9dee5", rough = 0.28}) => (
  <meshStandardMaterial color={color} metalness={0.6} roughness={rough} />
);

/* ---------- 1. Klip binder ---------- */
const Clip: React.FC<MP> = ({frame}) => {
  const shape = useMemo(() => {
    const s = new THREE.Shape();
    s.moveTo(-1.1, -0.8);
    s.lineTo(1.1, -0.8);
    s.lineTo(0.45, 0.55);
    s.lineTo(-0.45, 0.55);
    s.closePath();
    return s;
  }, []);
  const tilt = Math.sin(frame / 18) * 0.14;
  return (
    <group position={[0, -0.1, 0]}>
      <mesh position={[0, -0.2, -0.7]}>
        <extrudeGeometry args={[shape, {depth: 1.4, bevelEnabled: true, bevelThickness: 0.05, bevelSize: 0.05, bevelSegments: 3}]} />
        <meshStandardMaterial color="#20222b" roughness={0.38} metalness={0.25} />
      </mesh>
      {[-0.5, 0.5].map((z) => (
        <group key={z} position={[0, 0.35, z]} rotation={[0, 0, tilt * (z > 0 ? 1 : -1)]}>
          <mesh>
            <torusGeometry args={[0.52, 0.05, 12, 40, Math.PI]} />
            <Metal />
          </mesh>
        </group>
      ))}
      {/* tepi bawah berwarna */}
      <mesh position={[0, -1.0, 0]}>
        <boxGeometry args={[2.3, 0.08, 1.5]} />
        <Metal color="#9aa3b2" />
      </mesh>
    </group>
  );
};

/* ---------- 2. Karet gelang ---------- */
const Band: React.FC<MP> = ({frame}) => {
  const colors = ["#ffb020", "#ef4444", "#3b82f6"];
  return (
    <group rotation={[0.4, Math.sin(frame / 30) * 0.3, 0]} scale={1.05}>
      {colors.map((c, i) => (
        <mesh key={c} rotation={[(i * Math.PI) / 3, i * 0.8, 0]} scale={[1, 1, 1.5]}>
          <torusGeometry args={[1.1 + i * 0.13, 0.1, 24, 72]} />
          <meshStandardMaterial color={c} roughness={0.55} metalness={0.05} />
        </mesh>
      ))}
    </group>
  );
};

/* ---------- 3. Aluminium foil + gunting ---------- */
const Foil: React.FC<MP> = ({frame}) => {
  const open = 0.2 + 0.17 * Math.sin(frame / 6);
  return (
    <group scale={0.85}>
      <mesh position={[-1.7, 0.0, -0.4]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.55, 0.55, 1.9, 48]} />
        <Metal color="#e5e7eb" rough={0.35} />
      </mesh>
      <mesh position={[-1.7, 0.0, -0.4]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.2, 0.2, 1.95, 24]} />
        <meshStandardMaterial color="#c08457" roughness={0.8} />
      </mesh>
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <mesh key={i} position={[0.5 + (i % 2) * 0.04, -0.95 + i * 0.05, 0.2]} rotation={[0.35, 0.05 * (i % 3), 0]}>
          <boxGeometry args={[2.0, 0.03, 1.3]} />
          <Metal color="#eef1f5" rough={0.3} />
        </mesh>
      ))}
      <group position={[0.1, 0.75, 0.9]} rotation={[0, 0, 0.15]}>
        {[1, -1].map((dir) => (
          <group key={dir} rotation={[0, 0, dir * open]}>
            <mesh position={[0.8, 0, 0]}>
              <boxGeometry args={[1.6, 0.09, 0.05]} />
              <Metal color="#cbd5e1" rough={0.2} />
            </mesh>
            <mesh position={[-0.35, 0, 0]}>
              <boxGeometry args={[0.7, 0.08, 0.06]} />
              <meshStandardMaterial color="#ef4444" roughness={0.5} />
            </mesh>
            <mesh position={[-0.9, 0, 0]}>
              <torusGeometry args={[0.24, 0.05, 12, 32]} />
              <meshStandardMaterial color="#ef4444" roughness={0.5} />
            </mesh>
          </group>
        ))}
      </group>
    </group>
  );
};

/* ---------- 4. Tutup pulpen berlubang ---------- */
const Pen: React.FC<MP> = ({frame}) => {
  const particles = Array.from({length: 9}, (_, i) => {
    const t = (frame * 0.018 + i / 9) % 1;
    const y = -1.3 + t * 3.9;
    const spread = Math.sin(i * 2.1) * 0.3 * (1 - t * 0.9);
    const z = Math.cos(i * 1.3) * 0.25 * (1 - t * 0.9);
    return {y, x: spread, z, key: i};
  });
  return (
    <group rotation={[0.45, 0, -0.18]}>
      <mesh>
        <cylinderGeometry args={[0.55, 0.5, 2.4, 48]} />
        <meshStandardMaterial color="#3b82f6" roughness={0.25} metalness={0.15} transparent opacity={0.6} />
      </mesh>
      <mesh position={[0, 1.2, 0]}>
        <sphereGeometry args={[0.55, 40, 20, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial color="#3b82f6" roughness={0.25} metalness={0.15} transparent opacity={0.85} />
      </mesh>
      {/* lubang kecil */}
      <mesh position={[0, 1.755, 0]}>
        <cylinderGeometry args={[0.11, 0.11, 0.04, 24]} />
        <meshStandardMaterial color="#03040a" roughness={1} />
      </mesh>
      {/* klip */}
      <mesh position={[0.62, 0.35, 0]}>
        <boxGeometry args={[0.1, 1.6, 0.22]} />
        <Metal />
      </mesh>
      {/* partikel udara */}
      {particles.map((p) => (
        <mesh key={p.key} position={[p.x, p.y, p.z]}>
          <sphereGeometry args={[0.065, 12, 12]} />
          <meshStandardMaterial color="#a5f3fc" emissive="#22d3ee" emissiveIntensity={0.8} />
        </mesh>
      ))}
    </group>
  );
};

/* ---------- 5. Kantong silika gel ---------- */
const Silica: React.FC<MP> = ({frame}) => {
  const beads = useMemo(
    () =>
      Array.from({length: 46}, (_, i) => {
        const a = i * 2.399963;
        const r = Math.sqrt(i / 46);
        return [Math.cos(a) * r * 0.65, Math.sin(a * 1.3) * r * 0.9, ((i * 0.37) % 1 - 0.5) * 0.12] as [number, number, number];
      }),
    []
  );
  const edges = useMemo(() => new THREE.EdgesGeometry(new THREE.BoxGeometry(1.8, 2.4, 0.3)), []);
  const drops = Array.from({length: 6}, (_, i) => {
    const t = (frame * 0.015 + i / 6) % 1;
    return {x: 2.6 - t * 1.6, y: Math.sin(i * 1.7) * 1.0, s: 1 - t * 0.7, key: i};
  });
  return (
    <group rotation={[0.2, Math.sin(frame / 40) * 0.4, 0]}>
      <mesh>
        <boxGeometry args={[1.8, 2.4, 0.3]} />
        <meshStandardMaterial color="#f8fafc" transparent opacity={0.3} roughness={0.2} />
      </mesh>
      <lineSegments geometry={edges}>
        <lineBasicMaterial color="#ffffff" />
      </lineSegments>
      {beads.map((p, i) => (
        <mesh key={i} position={p}>
          <sphereGeometry args={[0.1, 16, 16]} />
          <meshStandardMaterial color="#60a5fa" roughness={0.1} metalness={0.1} />
        </mesh>
      ))}
      {drops.map((d) => (
        <mesh key={d.key} position={[d.x, d.y, 0.1]} scale={Math.max(0.01, d.s)}>
          <sphereGeometry args={[0.1, 14, 14]} />
          <meshStandardMaterial color="#38bdf8" emissive="#0ea5e9" emissiveIntensity={0.6} />
        </mesh>
      ))}
    </group>
  );
};

export const Model: React.FC<{type: ModelType; frame: number}> = ({type, frame}) => {
  switch (type) {
    case "clip": return <Clip frame={frame} />;
    case "band": return <Band frame={frame} />;
    case "foil": return <Foil frame={frame} />;
    case "pen": return <Pen frame={frame} />;
    case "silica": return <Silica frame={frame} />;
    default: return null;
  }
};

const Lights: React.FC = () => (
  <>
    <ambientLight intensity={1.0} />
    <directionalLight position={[4, 6, 5]} intensity={2.4} />
    <pointLight position={[-5, -2, 4]} intensity={40} color="#8ab4ff" />
    <pointLight position={[5, 3, -3]} intensity={25} color="#ffd29a" />
  </>
);

/** Satu objek 3D yang melayang & berputar. */
export const Stage3D: React.FC<{type: ModelType; width: number; height: number; scale?: number}> = ({
  type, width, height, scale = 1,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame: frame - 6, fps, config: {damping: 12, stiffness: 90}});
  return (
    <ThreeCanvas width={width} height={height} camera={{position: [0, 0, 7], fov: 40}}>
      <Lights />
      <group
        scale={Math.max(0.001, scale * enter)}
        position={[0, Math.sin(frame / 22) * 0.12, 0]}
        rotation={[0, frame * 0.015, 0]}
      >
        <Model type={type} frame={frame} />
      </group>
    </ThreeCanvas>
  );
};

/** Lima objek berjajar (untuk intro & thumbnail). */
export const ModelRow: React.FC<{
  width: number; height: number; animated?: boolean; spacing?: number; scale?: number;
}> = ({width, height, animated = true, spacing = 4.6, scale = 1}) => {
  const cf = useCurrentFrame();
  const {fps} = useVideoConfig();
  const frame = animated ? cf : 90;
  const types: ModelType[] = ["clip", "band", "foil", "pen", "silica"];
  return (
    <ThreeCanvas width={width} height={height} camera={{position: [0, 0, 11], fov: 40}}>
      <Lights />
      {types.map((t, i) => {
        const p = animated ? spring({frame: frame - 30 - i * 8, fps, config: {damping: 12}}) : 1;
        return (
          <group
            key={t}
            position={[(i - 2) * spacing, Math.sin(frame / 20 + i) * 0.2, 0]}
            scale={Math.max(0.001, p * scale)}
            rotation={[0, frame * 0.02 + i, 0]}
          >
            <Model type={t} frame={frame} />
          </group>
        );
      })}
    </ThreeCanvas>
  );
};
