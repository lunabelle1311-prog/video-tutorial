import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {BG} from "../theme";

export const Background: React.FC<{color: string}> = ({color}) => {
  const frame = useCurrentFrame();
  const bubbles = Array.from({length: 10}, (_, i) => {
    const size = 50 + ((i * 37) % 90);
    const left = (i * 173) % 100;
    const speed = 0.12 + (i % 4) * 0.05;
    const top = 110 - (((i * 61) % 100) + frame * speed) % 130;
    return {size, left, top, key: i};
  });
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(1100px 800px at ${72 + Math.sin(frame / 80) * 4}% ${42 + Math.cos(frame / 90) * 5}%, ${color}55, transparent 62%), linear-gradient(135deg, ${BG} 0%, #131c3a 100%)`,
      }}
    >
      <AbsoluteFill
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.04) 2px, transparent 2px), linear-gradient(90deg, rgba(255,255,255,0.04) 2px, transparent 2px)",
          backgroundSize: "90px 90px",
          backgroundPosition: `${frame * 0.4}px ${frame * 0.4}px`,
        }}
      />
      {bubbles.map((b) => (
        <div
          key={b.key}
          style={{
            position: "absolute",
            left: `${b.left}%`,
            top: `${b.top}%`,
            width: b.size,
            height: b.size,
            borderRadius: "50%",
            border: `3px solid ${color}44`,
            background: `${color}10`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};
