import {loadFont} from "@remotion/google-fonts/Poppins";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Jeda sebelum suara mulai & sesudah suara selesai (detik) pada tiap adegan
export const LEAD_SECONDS = 0.3;
export const TAIL_SECONDS = 0.9;

export const BG = "#0B1020";
export const INK = "#F8FAFC";
export const MUTED = "#CBD5E1";

const {fontFamily} = loadFont("normal", {
  weights: ["500", "600", "700", "800"],
  subsets: ["latin"],
});
export const FONT = `${fontFamily}, "Segoe UI", Arial, sans-serif`;
