import React from "react";
import {AbsoluteFill} from "remotion";
import {Stage3D} from "./components/Models3D";
import type {ModelType} from "./data";

export type IllustrationProps = {type: ModelType};

/** Ilustrasi 3D satu objek, latar transparan (render dengan --frame=60). */
export const Illustration: React.FC<IllustrationProps> = ({type}) => (
  <AbsoluteFill>
    <Stage3D type={type} width={1080} height={1080} scale={1.25} />
  </AbsoluteFill>
);
