import React from "react";
import {AbsoluteFill, Audio, interpolate, Sequence, Series, staticFile, useVideoConfig} from "remotion";
import {Fade} from "./components/Fade";
import {IntroScene} from "./scenes/IntroScene";
import {ItemScene} from "./scenes/ItemScene";
import {OutroScene} from "./scenes/OutroScene";
import {scenes} from "./data";
import {BG, FPS, LEAD_SECONDS} from "./theme";

export type VideoProps = {
  /** Durasi tiap adegan (frame), dihitung dari panjang file voice over */
  durations: number[];
  /** Apakah file voice over tersedia untuk adegan tersebut */
  voiceOk: boolean[];
};

export const MainVideo: React.FC<VideoProps> = ({durations, voiceOk}) => {
  const {durationInFrames} = useVideoConfig();
  return (
    <AbsoluteFill style={{backgroundColor: BG}}>
      <Audio
        src={staticFile("sfx/music.wav")}
        loop
        volume={(f) => interpolate(f, [0, 45, durationInFrames - 75, durationInFrames], [0, 0.09, 0.09, 0], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        })}
      />
      <Series>
        {scenes.map((s, i) => (
          <Series.Sequence key={s.id} durationInFrames={durations[i]}>
            <Fade duration={durations[i]}>
              {s.kind === "intro" && <IntroScene duration={durations[i]} />}
              {s.kind === "item" && s.item && <ItemScene item={s.item} duration={durations[i]} />}
              {s.kind === "outro" && <OutroScene duration={durations[i]} />}
            </Fade>
            {voiceOk[i] && (
              <Sequence from={Math.round(LEAD_SECONDS * FPS)} layout="none">
                <Audio src={staticFile(`voice/${s.id}.mp3`)} volume={1} />
              </Sequence>
            )}
          </Series.Sequence>
        ))}
      </Series>
    </AbsoluteFill>
  );
};
