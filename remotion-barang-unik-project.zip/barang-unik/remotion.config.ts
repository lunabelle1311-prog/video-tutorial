import {Config} from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// Wajib untuk render Three.js di Linux / Codespaces
Config.setChromiumOpenGlRenderer("angle");
// Render 3D di server tanpa GPU bisa lambat, jadi beri waktu lebih
Config.setDelayRenderTimeoutInMilliseconds(180000);
