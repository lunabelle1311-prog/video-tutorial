#!/usr/bin/env bash
set -e
sudo apt-get update
sudo apt-get install -y ffmpeg zip libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev \
  libasound2 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 \
  libatk-bridge2.0-0 libcups2 fonts-noto-color-emoji || true
pip install --user edge-tts gTTS || pip install --user --break-system-packages edge-tts gTTS
npm install
npx remotion browser ensure || true
echo "Siap! Jalankan: npm run build:all"
