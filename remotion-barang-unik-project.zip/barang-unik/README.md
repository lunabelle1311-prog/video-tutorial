# 🎬 5 Barang yang Jarang Diketahui Manfaatnya — Project Remotion

Video YouTube edukatif berbahasa Indonesia (1920×1080, 30 fps) yang dibuat sepenuhnya dengan kode:

| Elemen | Cara pembuatan |
|---|---|
| Ilustrasi 3D | Three.js (`@remotion/three`), dibangun dari bentuk dasar, tanpa file model eksternal |
| Voice over | `edge-tts` (suara Indonesia natural), fallback otomatis ke `gTTS` |
| Sound effect + musik latar | Dibuat prosedural oleh `scripts/generate-sfx.mjs` (bebas hak cipta) |
| Subtitle | Otomatis, disinkronkan dengan durasi voice over |
| Durasi video | Otomatis mengikuti panjang voice over tiap adegan |

Isi video: **Intro → 5 barang → Outro** (Klip Binder, Karet Gelang, Aluminium Foil, Lubang Tutup Pulpen, Silika Gel).

---

## 🚀 Cara pakai lewat GitHub Codespaces

1. Buat repository baru di GitHub, lalu unggah **seluruh isi folder ini** (termasuk folder tersembunyi `.devcontainer` dan `.github`).
2. Klik **Code → Codespaces → Create codespace on main**. Tunggu `setup.sh` selesai (memasang ffmpeg, Chrome, edge-tts, dan paket npm).
3. Di terminal Codespace jalankan:

```bash
npm run build:all
```

Perintah itu akan berurutan: membuat sound effect → membuat voice over → render video → render thumbnail → render ilustrasi 3D PNG → membuat ZIP.

4. Hasil akhir ada di **`out/barang-unik-youtube.zip`**. Klik kanan file tersebut di Explorer → **Download**.

### Isi ZIP
```
01-video/barang-unik.mp4
02-thumbnail/thumbnail.png
03-ilustrasi-3d/*.png        (PNG transparan tiap barang)
04-voice-over/*.mp3
05-sound-effect/*.wav        (+ music.wav)
06-naskah/naskah-voice-over.txt
06-naskah/metadata-youtube.txt   (judul, deskripsi, hashtag)
```

## ⚙️ Alternatif: GitHub Actions (tanpa membuka Codespace)

Push ke branch `main`, atau buka tab **Actions → Render Video YouTube → Run workflow**.
Setelah selesai, unduh ZIP dari bagian **Artifacts** pada halaman run.

---

## 🧪 Pratinjau & pengembangan

```bash
npm run sfx            # buat sound effect (sudah disertakan, jalankan ulang bila perlu)
npm run voice          # buat voice over
npm run dev            # buka Remotion Studio (port 3000) untuk preview langsung
npm run render:preview # render cepat resolusi 50% untuk cek hasil
```

> ⏱️ **Catatan waktu render:** objek 3D dirender dengan CPU (tanpa GPU), jadi video penuh bisa memakan waktu 30–90 menit di Codespace. Gunakan mesin **4 core** dan cek dulu dengan `render:preview`.

## ✏️ Mengubah isi video

Semua teks ada di **`src/content.json`**: judul, narasi, langkah-langkah, dan warna tiap barang. Ubah narasi lalu jalankan ulang:

```bash
FORCE=1 npm run voice
```

Pilihan suara dan kecepatan:

```bash
VOICE=id-ID-GadisNeural FORCE=1 npm run voice   # suara wanita
RATE=-10% FORCE=1 npm run voice                  # lebih lambat
```

Nama channel diganti lewat field `channel` di `content.json`.

## 🧩 Struktur kode

```
src/
  content.json          ← semua teks & narasi (edit di sini)
  Root.tsx              ← composition + durasi otomatis dari voice over
  MainVideo.tsx         ← urutan adegan, musik latar, voice over
  scenes/               ← IntroScene, ItemScene, OutroScene
  components/Models3D   ← model 3D (klip, karet, foil+gunting, pulpen, silika)
scripts/                ← sfx, voice, ilustrasi, zip
```

## ❓ Pemecahan masalah

- **Voice over gagal dibuat** → pastikan `pip install edge-tts gTTS`. Jika edge-tts diblokir, gTTS dipakai otomatis.
- **Render 3D gagal / layar hitam** → pastikan memakai `--gl=angle` (sudah diatur di script).
- **Error versi Remotion** → semua paket `@remotion/*` harus berversi sama. Untuk memperbarui: `npx remotion upgrade`.
